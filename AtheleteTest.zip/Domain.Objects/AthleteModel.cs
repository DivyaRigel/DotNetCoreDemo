﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain.Objects
{
    public class AthleteModel
    {
        public int ID { get; set; }
        public int UserRoleID { get; set; }
        public int TestTypeID { get; set; }
        public int AthleteID { get; set; }
        public string Name { get; set; }
        public int Distance  { get; set; }
        public bool IsActive { get; set; }
        public string FitnessRating { get; set; }

        [Required(ErrorMessage = "PLease enter Date!")]
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }        
        public IList<AthleteModel> AthleteModelList { get; set; }
        public IList<AthleteModel> AthleteList { get; set; }
    }
}
