﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain.Objects
{
    public class TestResultModel
    {
        [Required]
        public DateTime CreatedDate { get; set; }

        public int NoOfParticipants { get; set; }
        public int TestTypeID { get; set; }
        public int AthleteID { get; set; }
            
        [Required]
        public string TestType { get; set; }

        public IList<TestResultModel> TestResultList { get; set; }
        public IList<TestTypeModel> TestTypeList { get; set; }
    }
}
