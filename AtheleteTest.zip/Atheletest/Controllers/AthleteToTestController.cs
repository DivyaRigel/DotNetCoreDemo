﻿using Atheletest.Models;
using Domain.Objects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;

namespace Atheletest.Controllers
{
    public class AthleteToTestController : Controller
    {
        private AppSettings AppSettings { get; set; }

        public IActionResult Index()
        {
            int testTypeID = 0;
            testTypeID = Convert.ToInt32(HttpContext.Request.Query["testTypeID"]);

            if (testTypeID <= 0)
            {
                testTypeID = Convert.ToInt32(HttpContext.Session.GetString("testid"));
            }

            HttpContext.Session.SetString("testid", testTypeID.ToString());
            return View(TestResult.GetAthleteTestList(testTypeID));

        }

        [HttpPost]
        public IActionResult Index(AthleteModel objAtheleteModel)
        {
            objAtheleteModel.TestTypeID = Convert.ToInt32(HttpContext.Session.GetString("testid"));
            var abc = TestResult.AddAthleteInTest(objAtheleteModel);

            return RedirectToAction();
        }

        public ActionResult DeleteTest()
        {
            int testTypeID = Convert.ToInt32(HttpContext.Session.GetString("testid")); 

            if (testTypeID > 0)
                TestResult.DeleteTestById(testTypeID);

            return RedirectToAction("Index");
        }

        public ActionResult DeleteAthlete(int id)
        {
            int testTypeID = Convert.ToInt32(HttpContext.Session.GetString("testid")); //
            
            if (testTypeID > 0 && id >0)
                TestResult.DeleteAthleteById(id,testTypeID);

            return RedirectToAction("Index");
        }

        public AthleteToTestController(IOptions<AppSettings> settings)
        {
            AppSettings = settings.Value;
        }
    }
}