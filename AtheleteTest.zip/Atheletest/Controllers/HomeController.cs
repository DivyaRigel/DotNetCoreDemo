﻿using Atheletest.Models;
using Domain.Objects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Diagnostics;

namespace Atheletest.Controllers
{
    public class HomeController : Controller
    {
        private AppSettings AppSettings { get; set; }

        public HomeController(IOptions<AppSettings> settings)
        {
            AppSettings = settings.Value;
        }

        public IActionResult Index()
        {
            return View(TestResult.GetTestResults());
        }
        [HttpPost]
        public ActionResult Index(TestResultModel testResult)
        {
            if (ModelState.IsValid)
            {

               var testID = TestResult.AddTest(testResult);

                HttpContext.Session.SetString("testid", testID.ToString());
               return RedirectToAction("Index", "AthleteToTest");
            }
            else
            {
                TempData["Error"] = "There is some error with the validation of submitted values please check";
            }
            return RedirectToAction();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        public JsonResult getTestTypes()
        {
            return Json(TestResult.GetTestTypes());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
