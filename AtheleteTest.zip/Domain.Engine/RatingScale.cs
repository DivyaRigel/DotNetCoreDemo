﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Atheletest.Models
{
    public class RatingScale
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public int DistanceFrom { get; set; }

        public int DistanceTo { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }
    }
}
