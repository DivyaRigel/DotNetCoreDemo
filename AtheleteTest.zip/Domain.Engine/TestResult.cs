﻿using Dapper;
using Domain.Objects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Atheletest.Models
{
    public class TestResult
    {
        /// <summary>
        /// Get Test Results
        /// </summary>
        /// 
        public static TestResultModel GetTestResults()
        {
            TestResultModel objTestResult = new TestResultModel();
            objTestResult.TestResultList = new List<TestResultModel>();
            objTestResult.TestTypeList = new List<TestTypeModel>();

            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    objTestResult.TestResultList = con.Query<TestResultModel>("GetAllTestResults").ToList();
                    objTestResult.TestTypeList = con.Query<TestTypeModel>("GetAllTestTypes").ToList();

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objTestResult;
        }

        /// <summary>
        /// Get Athlete Test List
        /// </summary>
        /// <param name="id">Parameter TestTypeID</param>
        /// 
        public static AthleteModel GetAthleteTestList(int id)
        {
            AthleteModel objTestResult = new AthleteModel();
            objTestResult.AthleteList = new List<AthleteModel>();
            objTestResult.AthleteModelList = new List<AthleteModel>();

            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    objTestResult.AthleteList = con.Query<AthleteModel>("GetAllAthletes").ToList();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@TypeId", id);
                    objTestResult.AthleteModelList = con.Query<AthleteModel>("GetAllAthletesByTest", parameters, commandType: CommandType.StoredProcedure).ToList();

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objTestResult;
        }
        /// <summary>
        /// Add Athlete In Test
        /// </summary>
        /// <param name="object">Object Athelete model</param>
        /// 
        public static AthleteModel AddAthleteInTest(AthleteModel objAtheleteModel)
        {
            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AthleteID", objAtheleteModel.ID);
                    parameters.Add("@TestID", objAtheleteModel.TestTypeID);
                    parameters.Add("@Distance", objAtheleteModel.Distance);
                    parameters.Add("@CreatedDate", DateTime.Now);

                    con.Execute("InsertAthleteTest", parameters, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objAtheleteModel;
        }

        /// <summary>
        /// Add Test
        /// </summary>
        /// <param name="object">Object TestResult Model</param>
        /// 
        public static object AddTest(TestResultModel objTestResult)
        {
            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Name", objTestResult.TestType);
                    parameters.Add("@CreatedDate", objTestResult.CreatedDate);
                    parameters.Add("@new_identity", dbType: DbType.Int32, direction: ParameterDirection.Output);

                    con.Query("InsertTest", parameters, commandType: CommandType.StoredProcedure);
                    var test = parameters.Get<int>("@new_identity");
                    return test;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        /// <summary>
        /// Get All Test Types
        /// </summary>   
        /// 
        public static IList<TestTypeModel> GetTestTypes()
        {
            List<TestTypeModel> getAllTestTypes = new List<TestTypeModel>();

            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    getAllTestTypes = con.Query<TestTypeModel>("GetAllTestTypes").ToList();

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return getAllTestTypes;
        }


        /// <summary>
        /// Delete Test ById
        /// </summary> 
        /// <param name="testTypeId">testTypeId</param>
        /// 
        public static bool DeleteTestById(int testTypeId)
        {
            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@TestTypeID", testTypeId);
                    con.Execute("DeleteAtheleteTest", parameters, commandType: CommandType.StoredProcedure);
                }

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Delete Athlete By Id
        /// </summary> 
        /// <param name="athleteId,">athleteId</param>
        /// <param name="typeid">typeid</param>
        /// 
        public static bool DeleteAthleteById(int athleteId,int typeid)
        {
            try
            {
                using (IDbConnection con = new SqlConnection(AppSettings.ConnectionString))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AthleteID", athleteId);
                    parameters.Add("@testTypeId", typeid);
                    con.Execute("DeleteAtheleteFromTest", parameters, commandType: CommandType.StoredProcedure);
                }

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
